# 🚀 DEPLOYMENT GUIDE - Greece Golden Visa Calculator

This guide shows you the **3 easiest ways** to get your calculator live online.

---

## ⚡ OPTION 1: Vercel (EASIEST - 5 minutes)

**Vercel is the recommended option** - it's made by the Next.js creators and is completely free.

### Steps:

1. **Upload to GitHub:**
   - Go to [github.com](https://github.com) and sign in (or create free account)
   - Click "New Repository"
   - Name it "greece-visa-calculator"
   - Upload the entire `greece-visa-app` folder

2. **Deploy to Vercel:**
   - Go to [vercel.com](https://vercel.com)
   - Click "Sign up" and use your GitHub account
   - Click "Add New Project"
   - Select your `greece-visa-calculator` repository
   - Click "Deploy" (don't change any settings)

3. **Done!** 
   - Vercel will give you a live URL like: `greece-visa-calculator.vercel.app`
   - Share this URL with your client!
   - Updates: Just push to GitHub and Vercel auto-deploys

---

## 📦 OPTION 2: Netlify (Also Easy - 5 minutes)

### Steps:

1. **Upload to GitHub** (same as Option 1 above)

2. **Deploy to Netlify:**
   - Go to [netlify.com](https://netlify.com)
   - Sign up with GitHub
   - Click "Add new site" → "Import an existing project"
   - Choose GitHub and select your repository
   - Build settings:
     - Build command: `npm run build`
     - Publish directory: `.next`
   - Click "Deploy"

3. **Done!**
   - Get a URL like: `greece-visa-calculator.netlify.app`
   - You can customize the subdomain in settings

---

## 💻 OPTION 3: Replit (No GitHub needed - 3 minutes)

**Great if you want to avoid GitHub entirely.**

### Steps:

1. Go to [replit.com](https://replit.com)
2. Sign up (free)
3. Click "Create Repl"
4. Choose "Import from GitHub" OR "Upload folder"
5. If uploading: drag the entire `greece-visa-app` folder
6. Click "Run"
7. Replit will give you a live URL immediately!

---

## 🎨 OPTION 4: CodeSandbox (Instant Preview - 2 minutes)

**Perfect for quick demos, but URL is long.**

### Steps:

1. Go to [codesandbox.io](https://codesandbox.io)
2. Sign in with GitHub
3. Click "Create Sandbox"
4. Choose "Import from GitHub" or upload folder
5. Done! Instant live preview with shareable URL

---

## 🔧 Running Locally (For Development)

If you want to test on your computer first:

```bash
# Install dependencies
npm install

# Run development server
npm run dev
```

Then open http://localhost:3000 in your browser.

---

## 📝 RECOMMENDED WORKFLOW

**For a client project, I recommend:**

1. ✅ Upload to GitHub (you'll want version control anyway)
2. ✅ Deploy to Vercel (automatic deployments on every update)
3. ✅ Share the vercel.app URL with your client

**Benefits:**
- Professional URL
- Automatic HTTPS/SSL
- Every time you update GitHub, site auto-updates
- Free custom domain support
- Analytics included
- 99.99% uptime

---

## 🌐 Custom Domain (Optional)

If your client wants a custom domain like `visa-calculator.example.com`:

### On Vercel:
1. Go to your project settings
2. Click "Domains"
3. Add your domain
4. Update DNS records (Vercel provides instructions)

### On Netlify:
Same process - very straightforward!

**Cost:** Domain costs ~$10-15/year, hosting is FREE

---

## ❓ Need Help?

**Most Common Issues:**

1. **Build fails:** Make sure you uploaded the entire folder, not just files
2. **Page blank:** Check browser console for errors
3. **Styles missing:** Ensure `globals.css` is in the `app` folder

**Support:**
- Vercel: [vercel.com/support](https://vercel.com/support)
- Netlify: [netlify.com/support](https://netlify.com/support)

---

## 🎉 Summary

**Absolute Easiest:** Replit (no GitHub needed, instant)
**Best for Production:** Vercel (professional, auto-deploy, free)
**Good Alternative:** Netlify (similar to Vercel)
**Quick Demo:** CodeSandbox (instant but not for long-term)

**My recommendation: Vercel** ⭐
