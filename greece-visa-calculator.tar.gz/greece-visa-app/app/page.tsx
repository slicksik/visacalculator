import GreeceGoldenVisaCalculator from "@/components/GreeceGoldenVisaCalculator";

export default function Home() {
  return <GreeceGoldenVisaCalculator />;
}
